﻿namespace Interface
{
    public interface IOrderProcessor
    {
        void ProcessOrder();
        void CancelOrder();
    }
}
